
// ==== data ====
const MEMBERS = [
  {
    id: "anna",
    firstName: "Анна",
    lastName: "Иванова",
    age: 22,
    about: "Фронтенд-разработчик, любит UX и чистый код.",
    photo: "assets/placeholder.png",
    socials: [{name:"GitHub", url:"https://github.com/"},{name:"Telegram", url:"#"}],
    badge: { color: "blue", content: "Frontend" },
    contribution: "Собрала дизайн-систему, разработала Progress/Badge/Button.",
    skills: [
      { name: "HTML", percent: 90, color: "#22c55e", type: "bar" },
      { name: "CSS", percent: 85, color: "#5b9dff", type: "bar" },
      { name: "React", percent: 75, color: "#f59e0b", type: "circle" }
    ],
    portfolio: ["assets/placeholder.png","assets/placeholder.png","assets/placeholder.png"]
  },
  {
    id: "petr",
    firstName: "Пётр",
    lastName: "Сидоров",
    age: 24,
    about: "Тимлид и full‑stack. Любит типобезопасность и архитектуру.",
    photo: "assets/placeholder.png",
    socials: [{name:"LinkedIn", url:"#"},{name:"GitHub", url:"https://github.com/"}],
    badge: { color: "green", content: "Team Lead" },
    contribution: "Спроектировал FSD-архитектуру, настроил CI, деплой на GitHub Pages.",
    skills: [
      { name: "TypeScript", percent: 88, color: "#22c55e", type: "bar" },
      { name: "Node.js", percent: 70, color: "#5b9dff", type: "bar" },
      { name: "React", percent: 80, color: "#f59e0b", type: "circle" }
    ],
    portfolio: ["assets/placeholder.png"]
  },
  {
    id: "olga",
    firstName: "Ольга",
    lastName: "Кузнецова",
    age: 21,
    about: "UI инженер. Анимации, доступность и микро‑взаимодействия.",
    photo: "assets/placeholder.png",
    socials: [{name:"Behance", url:"#"}],
    badge: { color: "yellow", content: "UI/UX" },
    contribution: "Сверстала карточки, навбар, хлебные крошки и слайдер.",
    skills: [
      { name: "Figma", percent: 92, color: "#22c55e", type: "bar" },
      { name: "CSS", percent: 86, color: "#5b9dff", type: "bar" },
      { name: "GSAP", percent: 60, color: "#f59e0b", type: "circle" }
    ],
    portfolio: ["assets/placeholder.png","assets/placeholder.png"]
  }
];

// ==== utils ====
const $ = (sel, root=document) => root.querySelector(sel);
const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));

function navActive() {
  const path = location.pathname.split('/').pop();
  $$('.navbar .links a').forEach(a => {
    const href = a.getAttribute('href');
    if ((path === '' && href.endsWith('index.html')) || path === href) a.classList.add('active');
  });
}

function renderNavbar() {
  const nav = document.createElement('div');
  nav.className = 'navbar';
  nav.innerHTML = `
    <div class="brand">Команда • Картотека</div>
    <div class="links">
      <a href="index.html">Главная</a>
      <a href="favorites.html">Избранные</a>
      <a href="member.html?id=anna">Страница участника</a>
    </div>`;
  document.body.prepend(nav);
  navActive();
}

function renderFooter() {
  const footer = document.createElement('div');
  footer.className = 'footer';
  footer.innerHTML = '© ' + new Date().getFullYear() + ' Команда хакатона. Все права не защищены :)';
  document.body.appendChild(footer);
}

function getFavorites() {
  try { return JSON.parse(localStorage.getItem('favorites')||'[]'); } catch { return []; }
}
function setFavorites(ids) {
  localStorage.setItem('favorites', JSON.stringify(Array.from(new Set(ids))));
}
function toggleFavorite(id) {
  const favs = new Set(getFavorites());
  if (favs.has(id)) favs.delete(id); else favs.add(id);
  setFavorites(Array.from(favs));
  document.dispatchEvent(new CustomEvent('favorites:change'));
}

// ==== components ====
function Badge({color='blue', content=''}) {
  const span = document.createElement('span');
  span.className = `badge ${color}`;
  span.textContent = content;
  return span;
}

function Button({title='Кнопка', variant='primary', square=false, onClick}) {
  const b = document.createElement('button');
  b.className = `btn ${variant} ${square ? 'square' : ''}`;
  b.textContent = title;
  if (onClick) b.addEventListener('click', onClick);
  return b;
}

function ProgressBar({percent=0, color='#5b9dff', label='Навык'}) {
  const wrap = document.createElement('div');
  wrap.className = 'progress';
  wrap.innerHTML = `
    <div class="bar"><span></span></div>
    <div class="label"><span>${label}</span><span>${percent}%</span></div>
  `;
  wrap.querySelector('.bar > span').style.background = color;
  requestAnimationFrame(()=>{ wrap.querySelector('.bar > span').style.width = percent + '%'; });
  return wrap;
}

function ProgressCircle({percent=0, color='#5b9dff', label='Навык'}) {
  const r = 38, c = 2*Math.PI*r;
  const el = document.createElement('div');
  el.className = 'circle';
  el.innerHTML = `
    <svg width="88" height="88">
      <circle cx="44" cy="44" r="${r}" stroke="rgba(255,255,255,0.08)" stroke-width="8" fill="none" />
      <circle class="fg" cx="44" cy="44" r="${r}" stroke="${color}" stroke-width="8" fill="none"
        stroke-dasharray="${c}" stroke-dashoffset="${c}" stroke-linecap="round"/>
    </svg>
    <div class="center">${percent}%</div>
  `;
  requestAnimationFrame(()=>{
    el.querySelector('.fg').style.strokeDashoffset = c*(1 - percent/100);
  });
  const wrap = document.createElement('div');
  wrap.appendChild(el);
  const lab = document.createElement('div');
  lab.className = 'label';
  lab.style.textAlign = 'center';
  lab.style.marginTop = '6px';
  lab.style.color = 'var(--muted)';
  lab.textContent = label;
  wrap.appendChild(lab);
  return wrap;
}

function PersonCard(member) {
  const favs = new Set(getFavorites());
  const card = document.createElement('div');
  card.className = 'card person-card';
  card.innerHTML = `
    <img alt="${member.firstName}" src="${member.photo}"/>
    <div>
      <div class="name">${member.firstName} ${member.lastName}</div>
      <div class="about">${member.about}</div>
      <div class="meta"></div>
      <div class="actions" style="display:flex; gap:8px; flex-wrap:wrap;"></div>
    </div>
  `;
  card.querySelector('.meta').appendChild(Badge(member.badge));

  const actions = card.querySelector('.actions');
  actions.appendChild(Button({
    title: 'Открыть',
    variant: 'primary',
    onClick: () => location.href = `member.html?id=${member.id}`
  }));
  const favBtn = Button({
    title: favs.has(member.id) ? 'Удалить из избранного' : 'Добавить в избранное',
    variant: favs.has(member.id) ? 'danger' : 'success',
    onClick: () => { toggleFavorite(member.id); }
  });
  actions.appendChild(favBtn);

  document.addEventListener('favorites:change', () => {
    const has = new Set(getFavorites()).has(member.id);
    favBtn.textContent = has ? 'Удалить из избранного' : 'Добавить в избранное';
    favBtn.className = `btn ${has ? 'danger' : 'success'}`;
  });

  return card;
}

// simple slider
function Slider(images=[]) {
  const wrap = document.createElement('div');
  wrap.className = 'card';
  wrap.style.overflow = 'hidden';
  wrap.style.position = 'relative';

  const track = document.createElement('div');
  track.style.display = 'flex';
  track.style.transition = 'transform .4s ease';
  images.forEach(src => {
    const item = document.createElement('div');
    item.style.minWidth = '100%';
    item.innerHTML = `<img src="${src}" alt="" style="width:100%; height:240px; object-fit:cover; border-radius:12px" />`;
    track.appendChild(item);
  });
  wrap.appendChild(track);

  let idx = 0;
  const prev = Button({title:'←', square:true, onClick:()=>go(idx-1)});
  const next = Button({title:'→', square:true, onClick:()=>go(idx+1)});
  [prev,next].forEach(b=>{ b.style.position='absolute'; b.style.top='calc(50% - 18px)'; b.style.zIndex='2'; });
  prev.style.left='12px'; next.style.right='12px';
  wrap.appendChild(prev); wrap.appendChild(next);

  function go(i) {
    idx = (i+images.length) % images.length;
    track.style.transform = `translateX(${-idx*100}%)`;
  }
  return wrap;
}

// ==== pages ====
function pageIndex() {
  const root = document.querySelector('.container');
  const hero = document.createElement('div');
  hero.className = 'hero';
  hero.innerHTML = `
    <div>
      <h1>Сайт команды</h1>
      <p>Ниже — список участников. Используйте карточки, чтобы открыть страницу участника или добавить в избранное.</p>
    </div>
    <div class="card">
      <details class="summary">
        <summary>Что внутри сайта (раскрывающийся текст)</summary>
        <div class="content">
          • Общие компоненты: Navbar, Breadcrumbs, Card, Button, Badge, Progress (bar & circle).<br/>
          • Страницы: Главная, Страница участника, Избранные.<br/>
          • Локальное избранное хранится в localStorage.
        </div>
      </details>
    </div>
  `;
  root.appendChild(hero);

  const list = document.createElement('div');
  list.className = 'grid';
  MEMBERS.forEach(m => {
    const col = document.createElement('div');
    col.className = 'col-4';
    col.appendChild(PersonCard(m));
    list.appendChild(col);
  });
  root.appendChild(list);
}

function breadcrumbsTrail(items) {
  const wrap = document.createElement('div');
  wrap.className = 'breadcrumbs';
  items.forEach((item, i) => {
    if (item.href) {
      const a = document.createElement('a');
      a.href = item.href;
      a.textContent = item.label;
      wrap.appendChild(a);
    } else {
      const span = document.createElement('span');
      span.textContent = item.label;
      wrap.appendChild(span);
    }
    if (i < items.length - 1) {
      const sep = document.createElement('span'); sep.className='sep'; sep.textContent='›';
      wrap.appendChild(sep);
    }
  });
  return wrap;
}

function pageMember() {
  const params = new URLSearchParams(location.search);
  const id = params.get('id') || MEMBERS[0].id;
  const member = MEMBERS.find(m => m.id === id) || MEMBERS[0];

  const root = document.querySelector('.container');
  root.appendChild(breadcrumbsTrail([
    {label:'Главная', href:'index.html'},
    {label:'Участники', href:'index.html#members'},
    {label:`${member.firstName} ${member.lastName}`},
  ]));

  const top = document.createElement('div');
  top.className = 'grid';
  const left = document.createElement('div'); left.className='col-6';
  const right = document.createElement('div'); right.className='col-6';

  // left card
  const card = document.createElement('div'); card.className='card';
  card.innerHTML = `
    <div style="display:flex; gap:16px; align-items:center;">
      <img src="${member.photo}" alt="${member.firstName}" style="width:120px;height:120px;border-radius:16px;object-fit:cover;border:1px solid rgba(255,255,255,0.08)"/>
      <div>
        <h2 style="margin:0">${member.firstName} ${member.lastName}</h2>
        <div style="color:var(--muted);margin:6px 0 10px">Возраст: ${member.age}</div>
        <div class="socials"></div>
      </div>
    </div>
    <p style="color:var(--muted)">${member.about}</p>
    <div style="display:flex; gap:8px; align-items:center;"></div>
  `;
  const tags = card.querySelector('div[style*="display:flex; gap:8px"]');
  tags.appendChild(Badge(member.badge));
  const socials = card.querySelector('.socials');
  member.socials.forEach(s => {
    const a = document.createElement('a'); a.href=s.url; a.target='_blank'; a.rel='noreferrer'; a.textContent=s.name;
    socials.appendChild(a);
  });

  const actions = document.createElement('div');
  actions.style.display='flex'; actions.style.gap='8px'; actions.style.marginTop='12px';
  const favs = new Set(getFavorites());
  const favBtn = Button({
    title: favs.has(member.id) ? 'Удалить из избранного' : 'Добавить в избранное',
    variant: favs.has(member.id) ? 'danger' : 'success',
    onClick: ()=> toggleFavorite(member.id)
  });
  actions.appendChild(favBtn);
  card.appendChild(actions);
  document.addEventListener('favorites:change', () => {
    const has = new Set(getFavorites()).has(member.id);
    favBtn.textContent = has ? 'Удалить из избранного' : 'Добавить в избранное';
    favBtn.className = `btn ${has ? 'danger' : 'success'}`;
  });

  left.appendChild(card);

  // right skills
  const skills = document.createElement('div'); skills.className='card';
  skills.innerHTML = `<h3 style="margin-top:0">Навыки</h3>`;
  member.skills.forEach(s => {
    if (s.type === 'circle') {
      const row = document.createElement('div');
      row.style.display='inline-block'; row.style.margin='8px 12px 12px 0';
      row.appendChild(ProgressCircle({percent:s.percent, color:s.color, label:s.name}));
      skills.appendChild(row);
    } else {
      const row = document.createElement('div'); row.style.margin='10px 0';
      row.appendChild(ProgressBar({percent:s.percent, color:s.color, label:s.name}));
      skills.appendChild(row);
    }
  });
  right.appendChild(skills);

  top.appendChild(left); top.appendChild(right);
  root.appendChild(top);

  // contribution
  const contrib = document.createElement('div'); contrib.className='card';
  contrib.innerHTML = `<h3 style="margin-top:0">Чем занимался в проекте</h3><p style="color:var(--muted)">${member.contribution}</p>`;
  root.appendChild(contrib);

  if (member.portfolio && member.portfolio.length) {
    const slider = Slider(member.portfolio);
    root.appendChild(slider);
  }
}

function pageFavorites() {
  const root = document.querySelector('.container');
  root.appendChild(breadcrumbsTrail([
    {label:'Главная', href:'index.html'},
    {label:'Избранные'}
  ]));

  const list = document.createElement('div'); list.className='grid';
  function render() {
    list.innerHTML='';
    const favs = new Set(getFavorites());
    const favMembers = MEMBERS.filter(m => favs.has(m.id));
    if (!favMembers.length) {
      list.innerHTML = '';
      const empty = document.createElement('div');
      empty.className = 'card';
      empty.innerHTML = 'Пока пусто. Добавьте участников со страницы Главная или со страницы участника.';
      root.appendChild(empty);
      return;
    }
    favMembers.forEach(m => {
      const col = document.createElement('div'); col.className='col-4';
      const card = PersonCard(m);
      const addBtn = card.querySelector('.actions .btn.success');
      if (addBtn) { addBtn.textContent = 'Удалить из избранного'; addBtn.className = 'btn danger'; }
      col.appendChild(card);
      list.appendChild(col);
    });
  }
  render();
  document.addEventListener('favorites:change', () => { list.innerHTML=''; render(); });
  root.appendChild(list);
}

// ==== boot ====
function boot() {
  const body = document.body;
  renderNavbar();
  const container = document.createElement('div'); container.className='container';
  document.body.appendChild(container);

  const page = body.getAttribute('data-page');
  if (page === 'index') pageIndex();
  if (page === 'member') pageMember();
  if (page === 'favorites') pageFavorites();

  renderFooter();
}

document.addEventListener('DOMContentLoaded', boot);
